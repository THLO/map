"""
This is the version file for the map project.

More information about map is available at https://github.com/THLO/map.
"""

__version__ = "1.2.0"

__version_text__ = 'Copyright (C) 2016 Thomas Locher\n\
License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>.\n\
This is free software: you are free to change and redistribute it.\n\
There is NO WARRANTY, to the extent permitted by law.\n\n\
Written by Thomas Locher, see https://github.com/THLO/map.'
